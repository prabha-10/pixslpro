export interface LiquidGlassOptions {
  scale?: number;
  chroma?: number;
  border?: number;
  mapBlur?: number;
  blur?: number;
  saturate?: number;
  radius?: number | null;
  fallbackBlur?: number;
}

export interface LiquidGlassInstance {
  /** false when the browser fell back to a plain frosted blur. */
  supported: boolean;
  /** Re-render the displacement map (called automatically on resize). */
  refresh: () => void;
  /** Remove the filter + inline styles and stop observing. */
  destroy: () => void;
}

/**
 * Apply liquid glass to a DOM element. Framework-agnostic.
 * Safe to import during SSR; only call in the browser.
 */
export function liquidGlass(
  el: HTMLElement,
  opts?: LiquidGlassOptions,
): LiquidGlassInstance;
