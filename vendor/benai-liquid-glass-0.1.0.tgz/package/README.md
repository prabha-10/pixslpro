# @benai/liquid-glass

Apple-style **liquid-glass refraction** for React (and vanilla JS). Renders real
SVG displacement + chromatic aberration through `backdrop-filter` in Chromium,
and degrades to a clean frosted blur everywhere else.

- Zero runtime dependencies (browser APIs only)
- SSR-safe — safe to import in Server Components; the effect runs client-side
- Ships ESM + CJS + TypeScript types + a stylesheet
- Same tuned optics as the source design: `scale -112, chroma 6, blur 3, saturate 1.5`

> **Browser support:** the true refraction only renders in Chromium (Chrome/Edge).
> Safari and Firefox get an automatic frosted `blur()` fallback — the layout and
> readability are identical, just without the displacement.

## Install

This is a private package. Install it however you distribute internal packages:

```bash
# from a published registry
npm install @benai/liquid-glass

# or from a local path / tarball
npm install /path/to/liquid-glass
npm install ./benai-liquid-glass-0.1.0.tgz
```

Peer dependency: `react >= 18`.

## Usage

Import the stylesheet once at your app root (e.g. `app/layout.js` or `_app.js`):

```js
import '@benai/liquid-glass/styles.css';
```

### 1. Drop-in component

```jsx
import LiquidGlass from '@benai/liquid-glass';

<LiquidGlass variant="dark" glare>
  <h2>Join Aurora</h2>
  <p>Be the first to activate your space.</p>
</LiquidGlass>
```

Render as any element and pass through props:

```jsx
<LiquidGlass as="button" variant="light" preset="subtle" onClick={handleClick}>
  Click me
</LiquidGlass>
```

### 2. Hook (bring your own element)

```jsx
import { useLiquidGlass } from '@benai/liquid-glass';

function Card() {
  const ref = useLiquidGlass();            // default 'card' optics
  return <div ref={ref} className="glass">…</div>;
}
```

### 3. Vanilla JS (no React)

```js
import { liquidGlass } from '@benai/liquid-glass/vanilla';

const el = document.querySelector('.glass');
const instance = liquidGlass(el, { scale: -112, chroma: 6 });
// later: instance.destroy();
```

## API

### `<LiquidGlass>` props

| Prop | Type | Default | Notes |
|------|------|---------|-------|
| `as` | ElementType | `'div'` | Element/component to render |
| `variant` | `'dark' \| 'light' \| null` | `null` | Applies `.glass` / `.glass-light` dressing |
| `preset` | `'card' \| 'subtle'` | `'card'` | Optics preset |
| `options` | `LiquidGlassOptions` | — | Overrides individual optics values |
| `glare` | boolean | `false` | Adds a top-left specular highlight |
| `className`, `style`, `...rest` | | | Forwarded to the element |

### Optics presets

| Preset | scale | chroma | blur | saturate |
|--------|-------|--------|------|----------|
| `card` | -112 | 6 | 3 | 1.5 |
| `subtle` | -60 | 4 | 10 | 1.5 |

### Dressing classes (from `styles.css`)

- `.glass` — dark iOS-style tint with inset highlights
- `.glass-light` — white frosted glass for light backdrops
- `.glass-glare` — optional specular highlight child (or use `glare`)

## Build

```bash
npm install
npm run build     # → dist/ (ESM + CJS), keeps "use client" on the React entry
```

## License

MIT. Refraction engine adapted from
[deepika-builds/liquid-glass](https://github.com/deepika-builds/liquid-glass) (MIT).
