import type { CSSProperties, ElementType, ReactNode, RefObject } from 'react';

export interface LiquidGlassOptions {
  /** Displacement strength for the base channel. Negative = inward refraction. Default -112. */
  scale?: number;
  /** Per-channel offset that creates chromatic aberration. Default 6. */
  chroma?: number;
  /** Inset of the displacement map as a fraction of the shorter side. Default 0.07. */
  border?: number;
  /** Blur (px) applied to the displacement map. Default 12. */
  mapBlur?: number;
  /** Extra CSS blur (px) layered on top of the refraction. Default 3. */
  blur?: number;
  /** CSS saturate() multiplier. Default 1.5. */
  saturate?: number;
  /** Corner radius (px) for the map; null reads the element's computed radius. Default null. */
  radius?: number | null;
  /** Frosted blur (px) used on browsers without SVG-in-backdrop-filter support. Default 16. */
  fallbackBlur?: number;
}

export type LiquidGlassPreset = 'card' | 'subtle';

/** Built-in optics presets. `card` is the full effect; `subtle` is gentler. */
export const PRESETS: Record<LiquidGlassPreset, LiquidGlassOptions>;

/**
 * Attach liquid glass to your own element. Returns a ref to spread onto it.
 * The element should have a translucent background + border-radius
 * (e.g. the `.glass` / `.glass-light` classes) for the effect to read.
 */
export function useLiquidGlass(
  options?: LiquidGlassOptions,
  preset?: LiquidGlassPreset,
): RefObject<any>;

export interface LiquidGlassProps {
  /** Rendered element/component. Default 'div'. */
  as?: ElementType;
  /** Global dressing class: 'dark' → .glass, 'light' → .glass-light, null → none. */
  variant?: 'dark' | 'light' | null;
  /** Optics preset. Default 'card'. */
  preset?: LiquidGlassPreset;
  /** Overrides for individual optics values. */
  options?: LiquidGlassOptions;
  /** Render a top-left specular glare highlight. Default false. */
  glare?: boolean;
  className?: string;
  style?: CSSProperties;
  children?: ReactNode;
  [key: string]: unknown;
}

declare function LiquidGlass(props: LiquidGlassProps): JSX.Element;
export default LiquidGlass;
